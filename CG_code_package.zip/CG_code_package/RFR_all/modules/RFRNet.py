"""Network architecture of the covariate-guided RFR-Net.

The network follows the RFR-Net architecture (Li et al., 2020, Recurrent
Feature Reasoning for Image Inpainting, CVPR 2020), extended so that an
arbitrary number of covariate layers can be concatenated channel-wise to
the input of the first partial-convolution layer:

* the stem ``Pconv1`` receives ``1 + num_ext_features`` input channels
  (target variable + covariates);
* the validity mask is expanded accordingly, so that partial convolutions
  treat missing regions of the covariates consistently with the target
  variable.

The network consists of:

* the partial-convolution stem (``PartialConv2d``);
* a recurrent feature reasoning module (``RFRModule``) with 20 recurrent
  reasoning steps and a knowledge-consistent attention module;
* a decoding tail producing the reconstructed raster.

Reference
---------
Siyuan Ban, Fuyuan Jian, Kexin Zhou.
Covariate-guided reconstruction of missing geochemical data: An application
to mineral prospectivity mapping. Computers & Geosciences (manuscript).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models

from modules.partialconv2d import PartialConv2d
from modules.Attention import AttentionModule


class VGG16FeatureExtractor(nn.Module):
    """VGG16 feature extractor used by the perceptual/style losses.

    The first three convolutional blocks of a pretrained VGG16 are used and
    their parameters are frozen.
    """

    def __init__(self):
        super().__init__()
        try:
            # torchvision >= 0.13
            vgg16 = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1)
        except AttributeError:
            # torchvision < 0.13
            vgg16 = models.vgg16(pretrained=True)

        self.enc_1 = nn.Sequential(*vgg16.features[:5])
        self.enc_2 = nn.Sequential(*vgg16.features[5:10])
        self.enc_3 = nn.Sequential(*vgg16.features[10:17])

        # Freeze the encoder parameters.
        for i in range(3):
            for param in getattr(self, 'enc_{:d}'.format(i + 1)).parameters():
                param.requires_grad = False

    def forward(self, image):
        # Repeat single-band inputs to the 3 channels expected by VGG16.
        if image.shape[1] == 1:
            image = image.repeat(1, 3, 1, 1)
        results = [image]
        for i in range(3):
            func = getattr(self, 'enc_{:d}'.format(i + 1))
            results.append(func(results[-1]))
        return results[1:]


class Bottleneck(nn.Module):
    """Standard residual bottleneck block (1x1 -> 3x3 -> 1x1)."""

    expansion = 4

    def __init__(self, inplanes, planes, stride=1):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        out += residual
        out = self.relu(out)

        return out


class RFRModule(nn.Module):
    """Recurrent feature reasoning module.

    A U-Net-like encoder/decoder with a knowledge-consistent attention
    module between the third encoder and decoder levels.
    """

    def __init__(self, layer_size=6, in_channel=64):
        super(RFRModule, self).__init__()
        self.freeze_enc_bn = False
        self.layer_size = layer_size

        # Encoder: three strided stages 64 -> 128 -> 256.
        for i in range(3):
            name = 'enc_{:d}'.format(i + 1)
            out_channel = in_channel * 2
            block = [nn.Conv2d(in_channel, out_channel, 3, 2, 1, bias=False),
                     nn.BatchNorm2d(out_channel),
                     nn.ReLU(inplace=True)]
            in_channel = out_channel
            setattr(self, name, nn.Sequential(*block))

        # Encoder: three dilated stages keeping 512 channels.
        for i in range(3, 6):
            name = 'enc_{:d}'.format(i + 1)
            block = [nn.Conv2d(in_channel, out_channel, 3, 1, 2, dilation=2,
                               bias=False),
                     nn.BatchNorm2d(out_channel),
                     nn.ReLU(inplace=True)]
            setattr(self, name, nn.Sequential(*block))

        # Knowledge-consistent attention applied at the bottleneck.
        self.att = AttentionModule(512)

        # Decoder: two dilated stages (5 and 4).
        for i in range(5, 3, -1):
            name = 'dec_{:d}'.format(i)
            block = [nn.Conv2d(2 * in_channel, in_channel, 3, 1, 2,
                               dilation=2, bias=False),
                     nn.BatchNorm2d(in_channel),
                     nn.LeakyReLU(0.2, inplace=True)]
            setattr(self, name, nn.Sequential(*block))

        # Decoder: strided transposed convolutions (3, 2, 1). The channel
        # counts are expressed with in_channel arithmetic for clarity:
        # 1024 -> 512 -> 256 -> 64.
        in_channel *= 2

        block = [nn.ConvTranspose2d(in_channel, in_channel // 2, 4, 2, 1,
                                    bias=False),
                 nn.BatchNorm2d(in_channel // 2),
                 nn.LeakyReLU(0.2, inplace=True)]
        self.dec_3 = nn.Sequential(*block)

        block = [nn.ConvTranspose2d(in_channel // 4 * 3, in_channel // 4, 4,
                                    2, 1, bias=False),
                 nn.BatchNorm2d(in_channel // 4),
                 nn.LeakyReLU(0.2, inplace=True)]
        self.dec_2 = nn.Sequential(*block)

        block = [nn.ConvTranspose2d(in_channel // 16 * 6, in_channel // 16,
                                    4, 2, 1, bias=False),
                 nn.BatchNorm2d(in_channel // 16),
                 nn.LeakyReLU(0.2, inplace=True)]
        self.dec_1 = nn.Sequential(*block)

    def forward(self, input, mask):
        h_dict = {}  # outputs of enc_N

        h_dict['h_0'] = input

        h_key_prev = 'h_0'
        for i in range(1, self.layer_size + 1):
            l_key = 'enc_{:d}'.format(i)
            h_key = 'h_{:d}'.format(i)
            h_dict[h_key] = getattr(self, l_key)(h_dict[h_key_prev])
            h_key_prev = h_key
        h = h_dict[h_key]

        # Decoder with skip connections.
        for i in range(self.layer_size - 1, 0, -1):
            enc_h_key = 'h_{:d}'.format(i)
            dec_l_key = 'dec_{:d}'.format(i)
            h = torch.cat([h, h_dict[enc_h_key]], dim=1)
            h = getattr(self, dec_l_key)(h)
            if i == 3:
                # Knowledge-consistent attention at the bottleneck.
                h = self.att(h, mask)
        return h


class RFRNet(nn.Module):
    """Covariate-guided Recurrent Feature Reasoning Network.

    Parameters
    ----------
    num_ext_features : int
        Number of covariate layers concatenated to the input. With 0 the
        network degenerates to the baseline behaviour (single input band).

    The input raster and the covariates are repeatedly refined by 20
    recurrent reasoning steps; the intermediate feature maps are aggregated
    with a mask-weighted average before decoding.
    """

    def __init__(self, num_ext_features: int = 0):
        super(RFRNet, self).__init__()
        self.num_ext_features = num_ext_features
        # Input channels: 1 (target variable) + num_ext_features (covariates).
        self.Pconv1 = PartialConv2d(1 + num_ext_features, 64, 7, 2, 3,
                                    multi_channel=True, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.Pconv2 = PartialConv2d(64, 64, 7, 1, 3, multi_channel=True,
                                    bias=False)
        self.bn20 = nn.BatchNorm2d(64)
        self.Pconv21 = PartialConv2d(64, 64, 7, 1, 3, multi_channel=True,
                                     bias=False)
        self.Pconv22 = PartialConv2d(64, 64, 7, 1, 3, multi_channel=True,
                                     bias=False)
        self.bn2 = nn.BatchNorm2d(64)
        self.RFRModule = RFRModule(in_channel=64)
        self.Tconv = nn.ConvTranspose2d(64, 64, 4, 2, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(64)
        self.tail1 = PartialConv2d(64, 32, 3, 1, 1, multi_channel=True,
                                   bias=False)
        self.tail2 = Bottleneck(32, 8)
        self.out = nn.Conv2d(64, 1, 3, 1, 1, bias=False)

    def forward(self, in_image, mask, external_features):
        original_shape = in_image.shape[-2:]
        mask = mask.float()

        # Fuse the covariate layers with the masked target image.
        if self.num_ext_features > 0:
            # Concatenate the covariates along the channel dimension.
            external_features = torch.cat(external_features, dim=1)
            external_features = external_features.to(in_image.device)
            in_image = torch.cat([in_image, external_features], dim=1)

            # Expand the validity mask so that every covariate channel
            # shares the mask of the target variable.
            first_channel = mask[:, 0:1, :, :]
            additional_channels = first_channel.expand(
                -1, self.num_ext_features, -1, -1)
            mask = torch.cat([mask, additional_channels], dim=1)

        # Stem: partial convolutions with mask propagation.
        x1, m1 = self.Pconv1(in_image, mask)
        x1 = F.relu(self.bn1(x1), inplace=True)

        x1, m1 = self.Pconv2(x1, m1)
        x1 = F.relu(self.bn20(x1), inplace=True)
        x2 = x1
        x2, m2 = x1, m1

        # Recurrent feature reasoning: 20 reasoning steps. The feature and
        # mask tensors of every step are collected for the aggregation.
        n, c, h, w = x2.size()
        c = 64
        feature_group = []
        mask_group = []
        # Reset the recurrent attention state before the reasoning loop.
        self.RFRModule.att.att.att_scores_prev = None
        self.RFRModule.att.att.masks_prev = None
        for i in range(20):
            x2, m2 = self.Pconv21(x2, m2)
            x2, m2 = self.Pconv22(x2, m2)
            x2 = F.leaky_relu(self.bn2(x2), inplace=True)
            x2 = self.RFRModule(x2, m2[:, 0:1, :, :])
            x2 = x2 * m2
            feature_group.append(x2.view(n, c, 1, h, w))
            mask_group.append(m2.view(n, c, 1, h, w))

        # Mask-weighted aggregation of all reasoning steps.
        x3 = torch.cat(feature_group, dim=2)
        m3 = torch.cat(mask_group, dim=2)
        amp_vec = m3.mean(dim=2)
        x3 = (x3 * m3).mean(dim=2) / (amp_vec + 1e-7)
        x3 = x3.view(n, c, h, w)
        m3 = m3[:, :, -1, :, :]

        # Decoding tail.
        x4 = self.Tconv(x3)
        x4 = F.leaky_relu(self.bn3(x4), inplace=True)
        m4 = F.interpolate(m3, scale_factor=2)
        x5, _ = self.tail1(x4, m4)
        x5 = F.leaky_relu(x5, inplace=True)
        x6 = self.tail2(x5)
        x6 = torch.cat([x5, x6], dim=1)
        output = self.out(x6)
        return output, None

    def train(self, mode=True, finetune=False):
        """Switch training mode; during fine-tuning BatchNorm layers are
        kept in eval mode."""
        super().train(mode)
        if finetune:
            for name, module in self.named_modules():
                if isinstance(module, nn.BatchNorm2d):
                    module.eval()
