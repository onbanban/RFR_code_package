# Network modules of the covariate-guided RFR model.
