"""PyTorch dataset for covariate-guided reconstruction of GeoTIFF rasters.

Each dataset item is a tuple ``(image, mask, covariates, img_std,
cov_stds)`` where

* ``image`` is the normalized target raster (divided by its standard
  deviation), shape ``(1, H, W)``;
* ``mask`` marks valid pixels with 1 and missing pixels with 0,
  shape ``(1, H, W)``;
* ``covariates`` is a list of normalized covariate rasters, one tensor of
  shape ``(1, H, W)`` per covariate layer;
* ``img_std`` is the standard deviation used to normalize the target
  image (needed to restore the original data scale after inference);
* ``cov_stds`` is a list of the standard deviations of the covariates.

The covariate layers are read from the sub-directories of
``covariate_root``: every sub-directory corresponds to one covariate and
must contain one GeoTIFF per image, with file names sorted in the same
order as the images in ``image_path``. Mask files are single-band
GeoTIFFs in which pixels > 0 denote the missing (invalid) regions.
"""

import glob
import os
import random

import cv2
import numpy as np
import torch
import torchvision.transforms.functional as F
from PIL import Image
import rasterio


class Dataset(torch.utils.data.Dataset):
    """Dataset of single-band GeoTIFF images, masks and covariate layers."""

    def __init__(self, image_path, mask_path, covariate_root, mask_mode,
                 target_size, augment=False, training=True,
                 mask_reverse=False):
        super(Dataset, self).__init__()
        self.augment = augment
        self.training = training
        self.data = self.load_list(image_path)
        self.mask_data = self.load_list(mask_path)
        self.covariate_root = covariate_root
        self.covariate_subfolders = self.load_covariate_subfolders(
            covariate_root)
        # Accept a (height, width) tuple or list.
        self.target_size = target_size
        self.mask_type = mask_mode
        self.mask_reverse = mask_reverse

    def load_covariate_subfolders(self, root):
        """Collect the sub-directories (one per covariate layer) that
        contain GeoTIFF files."""
        subfolders = []
        if os.path.isdir(root):
            for dirpath, dirnames, filenames in os.walk(root):
                if filenames:
                    subfolders.append(dirpath)
        return subfolders

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        try:
            item = self.load_item(index)
        except Exception as e:
            print('loading error: {} - {}'.format(self.data[index], str(e)))
            item = self.load_item(0)
        return item

    def load_item(self, index):
        """Load, crop, resize and normalize one image/mask/covariates
        sample."""
        # Load image (first band of the GeoTIFF).
        with rasterio.open(self.data[index]) as src:
            img = src.read(1)

        # Load the covariate layers: every sub-folder provides one layer
        # matched to the current image index.
        complement_images = []
        for subfolder in self.covariate_subfolders:
            images = sorted(glob.glob(os.path.join(subfolder, '*.tif')))
            if index < len(images):
                with rasterio.open(images[index]) as src:
                    comp_img = src.read(1)
                complement_images.append(comp_img)
            else:
                raise IndexError(
                    'Index {} out of range for subfolder {}'.format(
                        index, subfolder))

        if self.training:
            img = self.resize(img)
            complement_images = [self.resize(comp_img)
                                 for comp_img in complement_images]
        else:
            img = self.resize(img, False, False, False)
            complement_images = [self.resize(comp_img, False, False, False)
                                 for comp_img in complement_images]

        # Load mask.
        mask = self.load_mask(img, index)

        # Data augmentation: randomly drop additional pixels.
        if self.training:
            if self.augment and np.random.binomial(1, 0.5) > 0:
                img, mask = self.apply_random_dropout(img, mask,
                                                      dropout_ratio=0.2)

        # Normalize every covariate to the value range of the target image,
        # then divide by its own standard deviation.
        processed_complement_images = []
        for comp_img in complement_images:
            comp_img_normalized = ((comp_img - np.min(comp_img))
                                   / (np.max(comp_img) - np.min(comp_img)
                                      + 1e-8)) * np.max(img)
            epsilon = 1e-20
            comp_img_norm_std = comp_img_normalized.std()
            comp_img_normalized = comp_img_normalized / (comp_img_norm_std
                                                         + epsilon)
            processed_complement_images.append(comp_img_normalized)

        # Normalize the target image by its standard deviation.
        img_norm_std = img.std()
        img = img / (img_norm_std + epsilon)

        return (
            self.to_tensor(img),
            self.to_tensor(mask),
            [self.to_tensor(comp_img)
             for comp_img in processed_complement_images],
            torch.tensor(img_norm_std),
            [torch.tensor(comp_img.std())
             for comp_img in processed_complement_images]
        )

    def apply_random_dropout(self, img, mask, dropout_ratio=0.2):
        """Randomly set a fraction of the pixels to zero (augmentation)."""
        height, width = img.shape

        # Create the dropout mask.
        dropout_mask = np.random.choice([0, 1], size=(height, width),
                                        p=[dropout_ratio, 1 - dropout_ratio])
        img = img.astype(np.float32)
        dropout_mask = dropout_mask.astype(np.float32)
        # Apply the dropout mask to the image.
        img = img * dropout_mask

        # Apply the dropout mask to the validity mask as well.
        mask = mask * dropout_mask.astype(np.float32)

        return img, mask

    def load_mask(self, img, index):
        """Load or generate the validity mask.

        ``self.mask_type`` selects the behaviour:

        * 0: external mask files, random order;
        * 1: randomly generated free-form masks;
        * 2: external mask files, fixed order (default).

        With ``mask_reverse=True`` the returned mask marks *valid* pixels
        with 255 (i.e. 1.0 after conversion to tensor).
        """
        imgh, imgw = img.shape

        # External mask, random order.
        if self.mask_type == 0:
            mask_index = random.randint(0, len(self.mask_data) - 1)
            with rasterio.open(self.mask_data[mask_index]) as src:
                mask = src.read(1)
            mask = (mask > 0).astype(np.uint8)  # Threshold due to interpolation
            mask = self.resize(mask, False)
            if self.mask_reverse:
                return (1 - mask) * 255
            return mask * 255

        # Randomly generated free-form mask.
        elif self.mask_type == 1:
            mask = 1 - generate_stroke_mask(self.target_size)
            mask = (mask > 0).astype(np.uint8) * 255
            mask = self.resize(mask, False)
            return mask

        # External mask, fixed order.
        elif self.mask_type == 2:
            mask_index = index
            with rasterio.open(self.mask_data[mask_index]) as src:
                mask = src.read(1)
            mask = (mask > 0).astype(np.uint8)  # Threshold due to interpolation
            mask = self.resize(mask, False)
            if self.mask_reverse:
                return (1 - mask) * 255
            return mask * 255

    def resize(self, img, aspect_ratio_kept=True, fixed_size=False,
               centerCrop=False):
        """Randomly crop (keeping the aspect ratio) and resize the image.

        Parameters
        ----------
        img : np.ndarray
            Input single-band image.
        aspect_ratio_kept : bool
            If True, crop a square patch out of the image first.
        fixed_size : bool
            If True, crop the largest possible square patch.
        centerCrop : bool
            If True (together with ``fixed_size``), crop the central square.
        """
        target_height, target_width = self.target_size

        if aspect_ratio_kept:
            imgh, imgw = img.shape
            side = np.minimum(imgh, imgw)
            if fixed_size:
                if centerCrop:
                    # Center crop.
                    j = (imgh - side) // 2
                    i = (imgw - side) // 2
                    img = img[j:j + side, i:i + side]
                else:
                    j = (imgh - side)
                    i = (imgw - side)
                    h_start = 0
                    w_start = 0
                    if j != 0:
                        h_start = random.randrange(0, j)
                    if i != 0:
                        w_start = random.randrange(0, i)
                    img = img[h_start:h_start + side, w_start:w_start + side]
            else:
                if side <= min(target_height, target_width):
                    j = (imgh - side)
                    i = (imgw - side)
                    h_start = 0
                    w_start = 0
                    if j != 0:
                        h_start = random.randrange(0, j)
                    if i != 0:
                        w_start = random.randrange(0, i)
                    img = img[h_start:h_start + side, w_start:w_start + side]
                else:
                    side = random.randrange(min(target_height, target_width),
                                            side)
                    j = (imgh - side)
                    i = (imgw - side)
                    h_start = random.randrange(0, j)
                    w_start = random.randrange(0, i)
                    img = img[h_start:h_start + side, w_start:w_start + side]

        # Resize to the target size (nearest neighbour to preserve labels).
        img = Image.fromarray(img)
        img = img.resize((target_width, target_height), resample=Image.NEAREST)
        img = np.array(img)
        return img

    def to_tensor(self, img):
        """Convert a NumPy image to a CHW torch tensor in [0, 1]."""
        img = Image.fromarray(img)
        img_t = F.to_tensor(img)
        return img_t

    def load_list(self, path):
        """Resolve a path into a sorted list of files.

        Supports a directory of ``*.tif`` files, a ``.txt`` file list or a
        single file path.
        """
        if isinstance(path, str):
            if path.endswith("txt"):
                with open(path, "r") as f:
                    lines = f.readlines()
                file_names = []
                for line in lines:
                    # Use os.path.join to make the paths relative to the
                    # list file location.
                    file_path = os.path.join(os.path.dirname(path),
                                             line.split(" ")[0].strip())
                    file_names.append(file_path)
                return file_names
            if os.path.isdir(path):
                path = list(glob.glob(os.path.join(path, '*.tif')))
                path.sort()
                return path
            if os.path.isfile(path):
                try:
                    return np.genfromtxt(path, dtype=str, encoding='utf-8')
                except Exception:
                    return [path]
        return []


def generate_stroke_mask(im_size, max_parts=15, maxVertex=25, maxLength=100,
                         maxBrushWidth=24, maxAngle=360):
    """Generate a random free-form (stroke) mask.

    The returned array has value 1 inside the strokes.
    """
    mask = np.zeros((im_size[0], im_size[1]), dtype=np.uint8)
    parts = random.randint(1, max_parts)
    for _ in range(parts):
        mask += np_free_form_mask(maxVertex, maxLength, maxBrushWidth,
                                  maxAngle, im_size[0], im_size[1])
    # Clip all values greater than 1 to 1.
    mask = np.minimum(mask, 1)
    return mask


def np_free_form_mask(maxVertex, maxLength, maxBrushWidth, maxAngle, h, w):
    """Draw one free-form stroke on a zero mask (value 1 inside the stroke)."""
    mask = np.zeros((h, w), dtype=np.uint8)
    numVertex = np.random.randint(maxVertex + 1)
    startY = np.random.randint(h)
    startX = np.random.randint(w)
    brushWidth = 0
    for i in range(numVertex):
        angle = np.random.randint(maxAngle + 1)
        angle = angle / 360.0 * 2 * np.pi
        if i % 2 == 0:
            angle = 2 * np.pi - angle
        length = np.random.randint(maxLength + 1)
        brushWidth = np.random.randint(10, maxBrushWidth + 1) // 2 * 2
        nextY = startY + length * np.cos(angle)
        nextX = startX + length * np.sin(angle)
        nextY = np.clip(nextY, 0, h - 1).astype(np.int64)
        nextX = np.clip(nextX, 0, w - 1).astype(np.int64)
        cv2.line(mask, (startX, startY), (nextX, nextY), 1, brushWidth)
        cv2.circle(mask, (startX, startY), brushWidth // 2, 1)
        startY, startX = nextY, nextX
    cv2.circle(mask, (startX, startY), brushWidth // 2, 1)
    return mask
