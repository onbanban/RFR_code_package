"""Command-line entry point for the covariate-guided RFR model.

This script trains or tests the covariate-guided Recurrent Feature
Reasoning Network (RFR-Net) for reconstructing missing regions in
single-band geochemical rasters. In addition to the target geochemical
variable, an arbitrary number of auxiliary covariate layers (e.g. DEM,
aeromagnetic data, fault proximity) can be fed to the network; the
covariates are concatenated channel-wise to the input of the first
partial-convolution layer.

This is the main difference with respect to the baseline variant (see the
``RFR`` package), which only accepts the target variable.

Reference
---------
Siyuan Ban, Fuyuan Jian, Kexin Zhou.
Covariate-guided reconstruction of missing geochemical data: An application
to mineral prospectivity mapping. Computers & Geosciences (manuscript).

Usage
-----
Train from scratch (with three covariates):
    python run.py --data_root ./data/train/images --mask_root ./data/train/masks
        --covariate_root ./data/train/covariates --n_ext_feat 3

Test (reconstruct the missing regions):
    python run.py --test --data_root ./data/test/images
        --mask_root ./data/test/masks --covariate_root ./data/test/covariates
        --n_ext_feat 3 --model_path ./checkpoints/g_final.pth
"""

import argparse
import os

from torch.utils.data import DataLoader

from dataset import Dataset
from model import RFRNetModel


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Covariate-guided RFR model for reconstruction of missing "
                    "geochemical data (supports multiple covariates).")
    parser.add_argument('--data_root', type=str, default='./data/train/images',
                        help='Root directory of single-band GeoTIFF images '
                             '(the target geochemical variable).')
    parser.add_argument('--mask_root', type=str, default='./data/train/masks',
                        help='Root directory of single-band GeoTIFF masks. '
                             'Pixels > 0 denote missing (invalid) regions.')
    parser.add_argument('--covariate_root', type=str,
                        default='./data/train/covariates',
                        help='Root directory of the covariate layers. Every '
                             'sub-directory corresponds to one covariate and '
                             'must contain one GeoTIFF per image, with file '
                             'names sorted in the same order as --data_root.')
    parser.add_argument('--model_save_path', type=str, default='./checkpoints',
                        help='Directory where model checkpoints are saved.')
    parser.add_argument('--result_save_path', type=str, default='./results',
                        help='Directory where reconstructed GeoTIFF images are '
                             'saved.')
    parser.add_argument('--target_size', type=int, nargs=2, default=(128, 128),
                        metavar=('HEIGHT', 'WIDTH'),
                        help='Patch size (height width) used for training/testing.')
    parser.add_argument('--mask_mode', type=int, default=2, choices=[0, 1, 2],
                        help='Mask source: 0 = external masks in random order, '
                             '1 = randomly generated free-form masks, '
                             '2 = external masks in fixed order (default).')
    parser.add_argument('--num_iters', type=int, default=10000,
                        help='Total number of training iterations.')
    parser.add_argument('--model_path', type=str, default=None,
                        help='Path to a checkpoint to resume from '
                             '(training) or to load (testing).')
    parser.add_argument('--batch_size', type=int, default=16,
                        help='Training batch size.')
    parser.add_argument('--n_threads', type=int, default=6,
                        help='Number of DataLoader worker threads.')
    parser.add_argument('--finetune', action='store_true',
                        help='Fine-tune the model (freezes BatchNorm layers '
                             'and uses a smaller learning rate).')
    parser.add_argument('--test', action='store_true',
                        help='Run testing/inference instead of training.')
    parser.add_argument('--gpu_id', type=str, default='0',
                        help='Index of the GPU to use.')
    parser.add_argument('--n_ext_feat', type=int, default=3,
                        help='Number of covariate layers fed to the network; '
                             'it must match the number of sub-directories '
                             'under --covariate_root.')
    return parser.parse_args()


def run():
    """Build the model, dataset and dataloader, then train or test."""
    args = parse_args()

    # Restrict the visible CUDA devices to the requested GPU.
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id

    # The number of covariate layers defines the input channel count of
    # the first partial-convolution layer (1 + n_ext_feat).
    model = RFRNetModel(num_ext_features=args.n_ext_feat)

    # Instantiate the dataset once so that the file lists are validated
    # before training/testing starts.
    Dataset(args.data_root, args.mask_root, args.covariate_root,
            args.mask_mode, args.target_size, mask_reverse=True)

    if args.test:
        # Testing mode: load the trained weights and run inference.
        model.initialize_model(args.model_path, False)
        model.cuda()
        dataloader = DataLoader(
            Dataset(args.data_root, args.mask_root, args.covariate_root,
                    args.mask_mode, args.target_size, mask_reverse=True,
                    training=False))
        model.test(dataloader, args.result_save_path)
    else:
        # Training mode: optionally resume from a checkpoint.
        model.initialize_model(args.model_path, True)
        model.cuda()
        dataloader = DataLoader(
            Dataset(args.data_root, args.mask_root, args.covariate_root,
                    args.mask_mode, args.target_size, mask_reverse=True),
            batch_size=args.batch_size, shuffle=True,
            num_workers=args.n_threads)
        model.train(dataloader, args.model_save_path, args.finetune,
                    args.num_iters)


if __name__ == '__main__':
    run()
