# Utility functions of the covariate-guided RFR model.
