"""Command-line entry point for the baseline RFR model (without covariates).

This script trains or tests the Recurrent Feature Reasoning Network (RFR-Net)
for reconstructing missing regions in single-band geochemical rasters. This is
the baseline variant of the model: only the target geochemical variable is
used as network input. The covariate-guided variant (see the ``RFR_cov``
package) additionally accepts auxiliary covariate layers.

Reference
---------
Siyuan Ban, Fuyuan Jian, Kexin Zhou.
Covariate-guided reconstruction of missing geochemical data: An application
to mineral prospectivity mapping. Computers & Geosciences (manuscript).

Usage
-----
Train from scratch:
    python run.py --data_root ./data/train/images --mask_root ./data/train/masks

Resume training from a checkpoint:
    python run.py --data_root ./data/train/images --mask_root ./data/train/masks
        --model_path ./checkpoints/g_1000.pth

Test (reconstruct the missing regions):
    python run.py --test --data_root ./data/test/images --mask_root ./data/test/masks
        --model_path ./checkpoints/g_final.pth
"""

import argparse
import os

from torch.utils.data import DataLoader

from dataset import Dataset
from model import RFRNetModel


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Baseline RFR model for reconstruction of missing geochemical "
                    "data (no covariate inputs).")
    parser.add_argument('--data_root', type=str, default='./data/train/images',
                        help='Root directory of single-band GeoTIFF images '
                             '(the target geochemical variable).')
    parser.add_argument('--mask_root', type=str, default='./data/train/masks',
                        help='Root directory of single-band GeoTIFF masks. '
                             'Pixels > 0 denote missing (invalid) regions.')
    parser.add_argument('--model_save_path', type=str, default='./checkpoints',
                        help='Directory where model checkpoints are saved.')
    parser.add_argument('--result_save_path', type=str, default='./results',
                        help='Directory where reconstructed GeoTIFF images are saved.')
    parser.add_argument('--target_size', type=int, nargs=2, default=(128, 128),
                        metavar=('HEIGHT', 'WIDTH'),
                        help='Patch size (height width) used for training/testing.')
    parser.add_argument('--mask_mode', type=int, default=2, choices=[0, 1, 2],
                        help='Mask source: 0 = external masks in random order, '
                             '1 = randomly generated free-form masks, '
                             '2 = external masks in fixed order (default).')
    parser.add_argument('--num_iters', type=int, default=50000,
                        help='Total number of training iterations.')
    parser.add_argument('--model_path', type=str, default=None,
                        help='Path to a checkpoint to resume from '
                             '(training) or to load (testing).')
    parser.add_argument('--batch_size', type=int, default=16,
                        help='Training batch size.')
    parser.add_argument('--n_threads', type=int, default=6,
                        help='Number of DataLoader worker threads.')
    parser.add_argument('--finetune', action='store_true',
                        help='Fine-tune the model (freezes BatchNorm layers '
                             'and uses a smaller learning rate).')
    parser.add_argument('--test', action='store_true',
                        help='Run testing/inference instead of training.')
    parser.add_argument('--gpu_id', type=str, default='0',
                        help='Index of the GPU to use.')
    return parser.parse_args()


def run():
    """Build the model, dataset and dataloader, then train or test."""
    args = parse_args()

    # Restrict the visible CUDA devices to the requested GPU.
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id

    model = RFRNetModel()

    # Instantiate the dataset once so that the file lists are validated
    # before training/testing starts.
    Dataset(args.data_root, args.mask_root, args.mask_mode, args.target_size,
            mask_reverse=True)

    if args.test:
        # Testing mode: load the trained weights and run inference.
        model.initialize_model(args.model_path, False)
        model.cuda()
        dataloader = DataLoader(
            Dataset(args.data_root, args.mask_root, args.mask_mode,
                    args.target_size, mask_reverse=True, training=False))
        model.test(dataloader, args.result_save_path)
    else:
        # Training mode: optionally resume from a checkpoint.
        model.initialize_model(args.model_path, True)
        model.cuda()
        dataloader = DataLoader(
            Dataset(args.data_root, args.mask_root, args.mask_mode,
                    args.target_size, mask_reverse=True),
            batch_size=args.batch_size, shuffle=True,
            num_workers=args.n_threads)
        model.train(dataloader, args.model_save_path, args.finetune,
                    args.num_iters)


if __name__ == '__main__':
    run()
