"""Model wrapper for the baseline RFR-Net (without covariates).

This module implements the training and testing logic of the Recurrent
Feature Reasoning Network (RFR-Net) applied to single-band geochemical
rasters. The generator (``RFRNet``) reconstructs the missing regions of a
raster, and the training loss combines:

* hole/valid L1 losses,
* style loss (Gram-matrix based),
* perceptual loss (VGG16 features),
* total-variation (TV) loss.

Only the target geochemical variable is used as input. See the ``RFR_cov``
package for the covariate-guided variant.
"""

import datetime
import os
import time

import cv2
import numpy as np
import torch
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter

from modules.RFRNet import RFRNet, VGG16FeatureExtractor
from utils.io import load_ckpt, save_ckpt


class RFRNetModel:
    """Wrapper class that bundles the generator, optimizer, losses and the
    training/testing loops of the baseline RFR model."""

    def __init__(self):
        self.G = None            # Generator (RFR-Net)
        self.lossNet = None      # VGG16 feature extractor used in the loss
        self.iter = None         # Current training iteration
        self.optm_G = None       # Optimizer of the generator
        self.device = None       # 'cuda' or 'cpu'
        self.real_A = None       # Masked input image
        self.real_B = None       # Ground-truth image
        self.fake_B = None       # Network prediction
        self.comp_B = None       # Composited output (prediction + valid pixels)
        self.l1_loss_val = 0.0   # Running L1 loss accumulator for logging

    def initialize_model(self, path=None, train=True):
        """Build the network and, if available, restore a checkpoint.

        Parameters
        ----------
        path : str or None
            Path to a checkpoint file. If the file cannot be loaded,
            training starts from scratch.
        train : bool
            Whether the model is initialized for training (the VGG16 loss
            network is only required for training).
        """
        self.G = RFRNet()
        self.optm_G = optim.Adam(self.G.parameters(), lr=2e-4)
        if train:
            self.lossNet = VGG16FeatureExtractor()
        try:
            start_iter = load_ckpt(path, [('generator', self.G)],
                                  [('optimizer_G', self.optm_G)])
            if train:
                self.optm_G = optim.Adam(self.G.parameters(), lr=2e-4)
                print('Model initialized, iter: ', start_iter)
                self.iter = start_iter
        except Exception:
            print('No trained model found, starting from scratch')
            self.iter = 0

    def cuda(self):
        """Move the networks to GPU if available, otherwise fall back to CPU."""
        if torch.cuda.is_available():
            self.device = torch.device("cuda")
            print("Model moved to cuda")
            self.G.cuda()
            if self.lossNet is not None:
                self.lossNet.cuda()
        else:
            self.device = torch.device("cpu")

    def train(self, train_loader, save_path, finetune=False, iters=10000):
        """Train the generator.

        Parameters
        ----------
        train_loader : torch.utils.data.DataLoader
            Dataloader providing (gt_image, mask, img_std) tuples.
        save_path : str
            Directory where checkpoints and TensorBoard logs are stored.
        finetune : bool
            If True, BatchNorm layers are kept in eval mode and a smaller
            learning rate (5e-5) is used.
        iters : int
            Total number of training iterations.
        """
        self.G.train(finetune=finetune)
        if finetune:
            self.optm_G = optim.Adam(
                filter(lambda p: p.requires_grad, self.G.parameters()), lr=5e-5)
        print("Starting training from iteration: {:d}".format(self.iter))
        s_time = time.time()

        # Use the current time as a suffix of the log directory so that every
        # run gets its own TensorBoard log folder.
        current_time = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        tb_log_dir = os.path.join(save_path, 'tb_logs_{}'.format(current_time))
        writer = SummaryWriter(log_dir=tb_log_dir)

        while self.iter < iters:
            for items in train_loader:
                gt_images, masks, norm_std = self.__cuda__(*items)
                # Mask the ground truth: valid pixels are kept, missing
                # pixels are set to zero.
                masked_images = gt_images * masks
                self.forward(masked_images, masks, gt_images)
                self.update_parameters()
                self.iter += 1

                if self.iter % 50 == 0:
                    e_time = time.time()
                    int_time = e_time - s_time
                    print("Iteration:%d, l1_loss:%.4f, time_taken:%.2f"
                          % (self.iter, self.l1_loss_val / 50, int_time))
                    # Write the averaged L1 loss to TensorBoard.
                    writer.add_scalar('Loss/l1_loss',
                                      self.l1_loss_val / 50, self.iter)
                    s_time = time.time()
                    self.l1_loss_val = 0.0

                if self.iter % 1000 == 0 or self.iter == iters:
                    if not os.path.exists('{:s}'.format(save_path)):
                        os.makedirs('{:s}'.format(save_path))
                    save_ckpt('{:s}/g_{:d}.pth'.format(save_path, self.iter),
                             [('generator', self.G)],
                             [('optimizer_G', self.optm_G)], self.iter)

        if not os.path.exists('{:s}'.format(save_path)):
            os.makedirs('{:s}'.format(save_path))
        save_ckpt('{:s}/g_{:s}.pth'.format(save_path, 'final'),
                  [('generator', self.G)],
                  [('optimizer_G', self.optm_G)], self.iter)
        writer.close()

    def test(self, test_loader, result_save_path):
        """Run inference and save the reconstructed rasters as GeoTIFF.

        Parameters
        ----------
        test_loader : torch.utils.data.DataLoader
            Dataloader providing (gt_image, mask, img_std) tuples. A batch
            size of 1 is expected (the default when no batch size is given).
        result_save_path : str
            Directory in which the ``results`` sub-folder is created.
        """
        self.G.eval()
        for para in self.G.parameters():
            para.requires_grad = False
        count = 0
        for items in test_loader:
            gt_images, masks, norm_std = self.__cuda__(*items)
            masked_images = gt_images * masks
            # Network prediction for the missing regions.
            fake_B, _ = self.G(masked_images, masks)
            # Composite: keep the observed (valid) pixels and fill the holes
            # with the network prediction.
            comp_B = fake_B * (1 - masks) + gt_images * masks
            masked_images = fake_B
            # Clip negative values and restore the original data scale
            # (the dataset normalizes each image by its standard deviation).
            comp_B = torch.clip(comp_B, 0, None) * norm_std
            if not os.path.exists('{:s}/results'.format(result_save_path)):
                os.makedirs('{:s}/results'.format(result_save_path))
            for k in range(comp_B.size(0)):
                count += 1
                # Convert the tensor to a NumPy array and remove the
                # single-channel dimension if present.
                comp_B_np = comp_B[k].detach().cpu().numpy()
                if comp_B_np.ndim == 3 and comp_B_np.shape[0] == 1:
                    comp_B_np = comp_B_np.squeeze(axis=0)
                # Save the reconstructed raster.
                file_path = '{:s}/results/img_{:d}.tif'.format(
                    result_save_path, count)
                cv2.imwrite(file_path, comp_B_np,
                            [cv2.IMWRITE_TIFF_XDPI, 96,
                             cv2.IMWRITE_TIFF_YDPI, 96])

                # Save the raw network prediction for the masked input.
                masked_images_np = masked_images[k].detach().cpu().numpy()
                if masked_images_np.ndim == 3 and masked_images_np.shape[0] == 1:
                    masked_images_np = masked_images_np.squeeze(axis=0)
                file_path = '{:s}/results/masked_img_{:d}.tif'.format(
                    result_save_path, count)
                masked_images_np = masked_images_np.astype(np.int16)
                cv2.imwrite(file_path, masked_images_np,
                            [cv2.IMWRITE_TIFF_XDPI, 96,
                             cv2.IMWRITE_TIFF_YDPI, 96])

    def forward(self, masked_image, mask, gt_image):
        """Forward pass of the generator."""
        self.real_A = masked_image
        self.real_B = gt_image
        self.mask = mask
        fake_B, _ = self.G(masked_image, mask)
        self.fake_B = fake_B
        self.comp_B = self.fake_B * (1 - mask) + self.real_B * mask

    def update_parameters(self):
        """Update the generator parameters."""
        self.update_G()
        self.update_D()

    def update_G(self):
        """One optimization step of the generator."""
        self.optm_G.zero_grad()
        loss_G = self.get_g_loss()
        loss_G.backward()
        self.optm_G.step()

    def update_D(self):
        """No discriminator is used in this model."""
        return

    def get_g_loss(self):
        """Compute the combined generator loss."""
        real_B = self.real_B
        fake_B = self.fake_B
        comp_B = self.comp_B

        real_B_feats = self.lossNet(real_B)
        fake_B_feats = self.lossNet(fake_B)
        comp_B_feats = self.lossNet(comp_B)

        tv_loss = self.TV_loss(comp_B * (1 - self.mask))
        style_loss = (self.style_loss(real_B_feats, fake_B_feats)
                      + self.style_loss(real_B_feats, comp_B_feats))
        preceptual_loss = (self.preceptual_loss(real_B_feats, fake_B_feats)
                           + self.preceptual_loss(real_B_feats, comp_B_feats))
        valid_loss = self.l1_loss(real_B, fake_B, self.mask)
        hole_loss = self.l1_loss(real_B, fake_B, (1 - self.mask))

        loss_G = (tv_loss * 0.1
                  + style_loss * 120
                  + preceptual_loss * 0.05
                  + valid_loss * 1
                  + hole_loss * 6)

        self.l1_loss_val += valid_loss.detach() + hole_loss.detach()
        return loss_G

    def l1_loss(self, f1, f2, mask=1):
        """Masked L1 loss between two tensors."""
        return torch.mean(torch.abs(f1 - f2) * mask)

    def style_loss(self, A_feats, B_feats):
        """Gram-matrix based style loss between two feature lists."""
        assert len(A_feats) == len(B_feats), \
            "the length of two input feature maps lists should be the same"
        loss_value = 0.0
        for i in range(len(A_feats)):
            A_feat = A_feats[i]
            B_feat = B_feats[i]
            _, c, w, h = A_feat.size()
            A_feat = A_feat.view(A_feat.size(0), A_feat.size(1),
                                 A_feat.size(2) * A_feat.size(3))
            B_feat = B_feat.view(B_feat.size(0), B_feat.size(1),
                                 B_feat.size(2) * B_feat.size(3))
            A_style = torch.matmul(A_feat, A_feat.transpose(2, 1))
            B_style = torch.matmul(B_feat, B_feat.transpose(2, 1))
            loss_value += torch.mean(torch.abs(A_style - B_style) / (c * w * h))
        return loss_value

    def TV_loss(self, x):
        """Total-variation loss (spatial smoothness)."""
        h_x = x.size(2)
        w_x = x.size(3)
        h_tv = torch.mean(torch.abs(x[:, :, 1:, :] - x[:, :, :h_x - 1, :]))
        w_tv = torch.mean(torch.abs(x[:, :, :, 1:] - x[:, :, :, :w_x - 1]))
        return h_tv + w_tv

    def preceptual_loss(self, A_feats, B_feats):
        """Perceptual loss between two VGG16 feature lists."""
        assert len(A_feats) == len(B_feats), \
            "the length of two input feature maps lists should be the same"
        loss_value = 0.0
        for i in range(len(A_feats)):
            A_feat = A_feats[i]
            B_feat = B_feats[i]
            loss_value += torch.mean(torch.abs(A_feat - B_feat))
        return loss_value

    def __cuda__(self, *args):
        """Move all tensor arguments to the active device."""
        return ((item.to(self.device) if isinstance(item, torch.Tensor) else item)
                for item in args)
