# Network modules of the baseline RFR model.
