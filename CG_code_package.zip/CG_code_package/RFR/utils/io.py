"""Utility functions for saving and loading PyTorch checkpoints."""

import torch
import torch.nn as nn


def get_state_dict_on_cpu(obj):
    """Return the state dictionary of a module with all tensors on CPU."""
    cpu_device = torch.device('cpu')
    state_dict = obj.state_dict()
    for key in state_dict.keys():
        state_dict[key] = state_dict[key].to(cpu_device)
    return state_dict


def save_ckpt(ckpt_name, models, optimizers, n_iter):
    """Save a checkpoint containing models, optimizers and the iteration.

    Parameters
    ----------
    ckpt_name : str
        Output file path of the checkpoint.
    models : list of (prefix, nn.Module)
        Models to store, each under the given prefix.
    optimizers : list of (prefix, Optimizer)
        Optimizers to store, each under the given prefix.
    n_iter : int
        Current iteration number.
    """
    ckpt_dict = {'n_iter': n_iter}
    for prefix, model in models:
        ckpt_dict[prefix] = get_state_dict_on_cpu(model)

    for prefix, optimizer in optimizers:
        ckpt_dict[prefix] = optimizer.state_dict()
    torch.save(ckpt_dict, ckpt_name)


def load_ckpt(ckpt_name, models, optimizers=None):
    """Load a checkpoint previously written by :func:`save_ckpt`.

    Parameters
    ----------
    ckpt_name : str
        Path of the checkpoint file.
    models : list of (prefix, nn.Module)
        Models whose weights are restored (non-strict matching).
    optimizers : list of (prefix, Optimizer) or None
        Optimizers whose states are restored.

    Returns
    -------
    int
        The iteration number stored in the checkpoint.
    """
    ckpt_dict = torch.load(ckpt_name)
    for prefix, model in models:
        assert isinstance(model, nn.Module)
        model.load_state_dict(ckpt_dict[prefix], strict=False)
    if optimizers is not None:
        for prefix, optimizer in optimizers:
            optimizer.load_state_dict(ckpt_dict[prefix])
    return ckpt_dict['n_iter']
