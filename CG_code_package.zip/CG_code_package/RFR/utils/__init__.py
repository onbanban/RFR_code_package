# Utility functions of the baseline RFR model.
