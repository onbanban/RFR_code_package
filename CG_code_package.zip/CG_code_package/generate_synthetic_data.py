"""Generate a synthetic example dataset for the RFR reconstruction models.

The geochemical data used in the manuscript are confidential and cannot be
shared. This script therefore generates a small *synthetic* example
dataset with exactly the same structure, so that the complete workflow
(data loading, training, testing) can be reproduced without access to the
real data. Replace the synthetic rasters with your own data following the
same directory layout (see ``data/README.md``).

The generated dataset contains:

* ``data/train/images``  : synthetic single-band geochemical rasters;
* ``data/train/masks``   : missing-region masks (255 = missing);
* ``data/train/covariates/{cov_1,cov_2,cov_3}`` : three synthetic
  covariate layers (only used by the ``RFR_cov`` model);
* the same structure under ``data/test``.

All rasters are written as single-band GeoTIFF files with a simple
georeference (unit pixel size, no CRS), which is sufficient for the
reconstruction workflow.

Usage
-----
    python generate_synthetic_data.py [--out ./data] [--n_train 40]
                                      [--n_test 10] [--size 128] [--seed 42]
"""

import argparse
import os

import numpy as np
import rasterio
from rasterio.transform import Affine


def smooth_random_field(rng, size, sigma=6):
    """Generate a spatially smooth random field via Gaussian filtering."""
    from scipy.ndimage import gaussian_filter
    noise = rng.standard_normal((size, size)).astype(np.float32)
    field = gaussian_filter(noise, sigma=sigma)
    # Normalize to the 0-100 range (arbitrary 'ppm-like' geochemical scale).
    field = field - field.min()
    field = field / (field.max() + 1e-8) * 100.0
    return field.astype(np.float32)


def random_missing_mask(rng, size, max_parts=8):
    """Generate a binary missing-region mask (255 = missing).

    Missing regions are unions of random rectangular blocks, mimicking
    irregularly distributed gaps in stream-sediment geochemical surveys.
    """
    mask = np.zeros((size, size), dtype=np.uint8)
    parts = rng.integers(3, max_parts + 1)
    for _ in range(parts):
        h = int(rng.integers(size // 10, size // 2))
        w = int(rng.integers(size // 10, size // 2))
        y = int(rng.integers(0, size - h + 1))
        x = int(rng.integers(0, size - w + 1))
        mask[y:y + h, x:x + w] = 255
    return mask


def write_geotiff(path, array):
    """Write a single-band GeoTIFF with a simple georeference."""
    height, width = array.shape
    profile = {
        'driver': 'GTiff',
        'height': height,
        'width': width,
        'count': 1,
        'dtype': array.dtype,
        'crs': None,  # Synthetic data: no coordinate reference system.
        'transform': Affine(1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
    }
    with rasterio.open(path, 'w', **profile) as dst:
        dst.write(array, 1)


def generate_split(out_root, n_samples, size, rng, with_covariates=True):
    """Generate images, masks and (optionally) covariates for one split."""
    img_dir = os.path.join(out_root, 'images')
    mask_dir = os.path.join(out_root, 'masks')
    os.makedirs(img_dir, exist_ok=True)
    os.makedirs(mask_dir, exist_ok=True)

    cov_dirs = []
    if with_covariates:
        # Three synthetic covariates: e.g. topography, geophysics and
        # fault proximity. Each sub-directory holds one layer per image.
        cov_dirs = [os.path.join(out_root, 'covariates', 'cov_1'),
                    os.path.join(out_root, 'covariates', 'cov_2'),
                    os.path.join(out_root, 'covariates', 'cov_3')]
        for d in cov_dirs:
            os.makedirs(d, exist_ok=True)

    for i in range(n_samples):
        name = 'sample_{:04d}.tif'.format(i)

        # Target geochemical variable (smooth random field).
        image = smooth_random_field(rng, size)

        # Missing-region mask (255 = missing).
        mask = random_missing_mask(rng, size)

        write_geotiff(os.path.join(img_dir, name), image)
        write_geotiff(os.path.join(mask_dir, name), mask)

        if with_covariates:
            # cov_1: correlated with the target variable plus noise
            #        (e.g. a pathfinder element).
            cov1 = image + rng.standard_normal((size, size)).astype(
                np.float32) * 5.0
            # cov_2: an independent regional gradient field
            #        (e.g. topography).
            cov2 = smooth_random_field(rng, size, sigma=12)
            # cov_3: distance-to-source like field with small-scale
            #        structures (e.g. fault proximity).
            cov3 = smooth_random_field(rng, size, sigma=2)
            for d, cov in zip(cov_dirs, (cov1, cov2, cov3)):
                write_geotiff(os.path.join(d, name), cov)


def main():
    parser = argparse.ArgumentParser(
        description="Generate a synthetic example dataset with the same "
                    "structure as the confidential real data.")
    parser.add_argument('--out', type=str, default='./data',
                        help='Output root directory.')
    parser.add_argument('--n_train', type=int, default=40,
                        help='Number of training samples.')
    parser.add_argument('--n_test', type=int, default=10,
                        help='Number of testing samples.')
    parser.add_argument('--size', type=int, default=128,
                        help='Raster size (square, in pixels).')
    parser.add_argument('--seed', type=int, default=42,
                        help='Random seed for reproducibility.')
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)

    print('Generating synthetic training data ...')
    generate_split(os.path.join(args.out, 'train'), args.n_train,
                   args.size, rng, with_covariates=True)
    print('Generating synthetic test data ...')
    generate_split(os.path.join(args.out, 'test'), args.n_test,
                   args.size, rng, with_covariates=True)
    print('Done. Synthetic dataset written to {}'.format(
        os.path.abspath(args.out)))


if __name__ == '__main__':
    main()
