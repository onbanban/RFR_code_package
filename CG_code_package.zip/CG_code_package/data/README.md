# Data Directory (template)

The geochemical data used in the manuscript are **confidential and cannot
be shared publicly**. This directory is a placeholder that documents the
expected data layout. Run `python generate_synthetic_data.py` (from the
package root) to fill this directory with a synthetic example dataset of
the same structure, or place your own data following the layout below.

## Expected layout

```
data/
├── train/
│   ├── images/              # Target geochemical variable, single-band GeoTIFF
│   │   ├── sample_0000.tif  #   (one file per raster patch)
│   │   └── ...
│   ├── masks/               # Missing-region masks, single-band GeoTIFF
│   │   ├── sample_0000.tif  #   (pixel value > 0  ==>  missing region)
│   │   └── ...
│   └── covariates/          # Only required by the RFR_all model
│       ├── cov_1/           # Covariate layer 1 (e.g. DEM)
│       │   ├── sample_0000.tif
│       │   └── ...
│       ├── cov_2/           # Covariate layer 2 (e.g. aeromagnetic data)
│       └── cov_3/           # Covariate layer 3 (e.g. fault proximity)
└── test/
    ├── images/
    ├── masks/
    └── covariates/
        ├── cov_1/
        ├── cov_2/
        └── cov_3/
```

## Rules

1. **Images** (`images/`): single-band GeoTIFF rasters of the target
   geochemical variable. File names must sort in the same order as the
   corresponding masks and covariates (e.g. identical file names).

2. **Masks** (`masks/`): single-band GeoTIFF with the same size as the
   corresponding image. Pixels > 0 mark the **missing (invalid)** regions
   to be reconstructed.

3. **Covariates** (`covariates/`): every sub-directory is one covariate
   layer and must contain exactly one GeoTIFF per image, with file names
   sorted in the same order as `images/`. The number of sub-directories
   must match the `--n_ext_feat` command-line argument of `RFR_all/run.py`.
   The baseline `RFR` model does not use this directory.

4. All rasters of one sample (image, mask, covariates) should have the
   same spatial extent; patches are cropped and resized to
   `--target_size` during loading.
